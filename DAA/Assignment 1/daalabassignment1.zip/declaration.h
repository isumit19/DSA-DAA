#include<stdio.h>
void selection(int a[],int n);
void bubble(int a[],int n);
void insertion(int a[],int n);
void quickSort(int a[], int l, int h);
int partition (int a[], int l, int h);
void merge(int a[],int l1,int h1,int l2,int h2);
void MergeSort(int a[],int low,int high);
void generator(int n,char file_name[]);
