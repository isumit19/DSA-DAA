#include<stdio.h>
#include "declaration.h"
void merge(int a[],int l1,int h1,int l2,int h2)
{
    int temp[h2-l1+1];   
    int i=l1,j=l2,k=0,d=0;   
    
    while(i<=h1 && j<=h2)   
    {
        if(a[i]<a[j])
            temp[k++]=a[i++];
        else
            temp[k++]=a[j++];
    }
    
    while(i<=h1)  
        temp[k++]=a[i++];
        
    while(j<=h2)    
        temp[k++]=a[j++];
        
   
    for(i=l1,j=0;i<=h2;i++,j++)
        a[i]=temp[j];

        
}

void MergeSort(int a[],int low,int high)
{
	if(low<high)
		{int mid=(low+high)/2;
		MergeSort(a,low,mid);
		MergeSort(a,mid+1,high);
		merge(a,low,mid,mid+1,high);
		}
	
}
