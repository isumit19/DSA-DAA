#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<stdint.h>
#include "declaration.h"
#define mod 10000007
char file_name[]="number.txt";



long get_time()
{
	struct timeval tv;
	gettimeofday(&tv,NULL);
	return (((tv.tv_sec*1e+6)+tv.tv_usec));
}
int* file_read(int *n)
{
	int *a;
	FILE *f;
	f = fopen(file_name,"r");
	int i;
	fscanf(f,"%d",n);
	a=(int *)malloc((*n)*sizeof(int));
	for(i=0;i<*n;i++)
		fscanf(f,"%d",a+i);
	fclose(f);
	return a;
}
void read_selection()
{
	int *a;
	int i,n;
	a=file_read(&n);		
	long time_start=get_time();
	selection(a,n);
	long time_end=get_time();
	printf("Time of Selection Sort : %ld\n",time_end-time_start);
		
}

void read_insertion()
{
	int *a;
	int i,n;
	a=file_read(&n);	
	long time_start=get_time();
	insertion(a,n);
	long time_end=get_time();
	printf("Time of Insertion Sort : %ld\n",time_end-time_start);
		
}

void read_bubble()
{
	FILE *f;
	f = fopen(file_name,"r");
	int n,i;
	fscanf(f,"%d",&n);
	int a[n];
	for(i=0;i<n;i++)
		fscanf(f,"%d",&a[i]);
	fclose(f);	
		
	long time_start=get_time();
	bubble(a,n);
	long time_end=get_time();
	printf("Time of Bubble Sort : %ld\n",time_end-time_start);
		
}

void read_quick()
{
	int *a;
	int i,n;
	a=file_read(&n);		
	long time_start=get_time();
	quickSort(a,0,n-1);
	long time_end=get_time();
	printf("Time of Quick Sort : %ld\n",time_end-time_start);
}

void read_merge()
{
	int *a;
	int i,n;
	a=file_read(&n);
	long time_start=get_time();
	MergeSort(a,0,n-1);
	long time_end=get_time();
	printf("Time of Merge Sort : %ld\n",time_end-time_start);
}
void Sorting_Time_Display()
{	
	read_quick();
	read_merge();
	read_selection();
	read_insertion();
	read_bubble();

}
int main()
{

		int n;
		printf("\nEnter the number of elements u want to Sort : ");
		scanf("%d",&n);
		generator(n,file_name);
		printf("\nFor %d\n",n);
		Sorting_Time_Display();
	
}
