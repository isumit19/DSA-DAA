#include<stdio.h>
#include<stdlib.h>
#include<time.h> 
#define mod 99999999
void generator(int n,char file_name[])
{

	FILE *f;
	f=fopen(file_name,"w");
	int i;
	fprintf(f,"%d\n",n);
	for(i=0;i<n;i++)
		fprintf(f,"%d ",rand()%mod);
	fclose(f);
	
}

