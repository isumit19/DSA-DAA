#include<stdio.h>
#include "declaration.h"
void selection(int a[],int n)
{
	int i,j;
	for(i=0;i<n;i++)
	{
		int small =a[i];
		int pos=i;
		for(j=i+1;j<n;j++)
		{
			if(a[j]<small)
			{
				small=a[j];
				pos=j;
			}
		}
		int temp=a[i];
		a[i]=a[pos];
		a[pos]=temp;
	}
}
