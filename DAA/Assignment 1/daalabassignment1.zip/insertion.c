#include<stdio.h>
#include "declaration.h"
void insertion(int a[],int n)
{
	int i,j;
	for(i=1;i<n;i++)
	{
		j=i-1;
		int temp=a[i];
		while(j>=0 && a[j]>temp)
		{
			a[j+1]=a[j];
			j--;
		}
		a[j+1]=temp;
	}
	
}
