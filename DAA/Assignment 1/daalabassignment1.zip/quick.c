#include<stdio.h>
#include "declaration.h"


int partition (int a[], int l, int h) 
{ 
    int pivot = a[h];  
    int i = (l - 1);  
  
    for (int j = l; j <= h- 1; j++) 
    { 

        if (a[j] <= pivot) 
        { 
            i++;  
            int temp=a[i];
            a[i]=a[j];
            a[j]=temp;
        } 
    } 

            int temp=a[i+1];
            a[i+1]=a[h];
            a[h]=temp;
    return (i + 1); 
} 
  

void quickSort(int a[], int l, int h) 
{ 
    if (l < h) 
    { 
 
        int pi = partition(a, l, h); 

        quickSort(a, l, pi - 1); 
        quickSort(a, pi + 1, h); 
    } 
} 
   
   


