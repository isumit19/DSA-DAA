#include "head.h"
int BRUTE(char x[],char y[],int k,int l){
	if(k==0 || l==0)
		return 0;
	if(x[k-1]==y[l-1]){
		int g=1+BRUTE(x,y,k-1,l-1);
		str_brute[g-1]=x[k-1];
		return g;
	}	
	else
		return BRUTE(x,y,k-1,l)>BRUTE(x,y,k,l-1)?BRUTE(x,y,k-1,l):BRUTE(x,y,k,l-1);
}
