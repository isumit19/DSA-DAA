#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define INT_MAX 100
char str_dp[INT_MAX],str_brute[INT_MAX];
int c_table[INT_MAX][INT_MAX],b_table[INT_MAX][INT_MAX];
void LCS(char [],char [],int,int);
int BRUTE(char [],char [],int,int);
int max(int,int);
void print_lcs(char [],int,int);
void print_table(int,int);
