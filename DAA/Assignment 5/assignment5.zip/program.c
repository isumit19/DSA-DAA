#include "head.h"
#include<sys/time.h>
long get_time()
{
	struct timeval tv;
	gettimeofday(&tv,NULL);
	return (((tv.tv_sec*1e+6)+tv.tv_usec));
}

int main(){
	long time_start,time_end;
	char a[INT_MAX],b[INT_MAX];
	
	FILE *f=fopen("output.txt","w");
	
	FILE *f=fopen("input.txt","r");
	fscanf(f,"%s%s",a,b);
	
	int X=strlen(a),Y=strlen(b);
	
	time_start=get_time();
	LCS(a,b,X,Y);
	time_end=get_time();
	
	printf("Time through DP : %ld\n",time_end-time_start);
	
	
	printf("Length : %d ",c_table[X][Y]);
	print_lcs(a,X,Y);
	print_table(X,Y);
	
	time_start=get_time();
	int len_brute=BRUTE(a,b,X,Y);
	time_end=get_time();
	
	printf("\nTime through Brute Force : %ld",time_end-time_start);
	printf("\n%d %s",len_brute,str_brute);
	
}
