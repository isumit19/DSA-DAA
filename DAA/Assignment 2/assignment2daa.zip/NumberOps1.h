#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"Number.h"
#include"BaseOps.h"
FILE *f;
void push(Number* num,char c);
void PrintNumber(Number x);
void display(Number a,char op,Number b,Number r);
Number createNumber(char *number_format);
int toDec(Number n);
Number fromDec(int inputNum, int base);
Number add(Number a, Number b);
Number sub(Number a, Number b);
Number convert(Number n,int to_base);
int max(int a,int b);
void string_create(char string[],int base,int number);
char reVal(int num) ;
void check(int base);
list* newnode(char c);
