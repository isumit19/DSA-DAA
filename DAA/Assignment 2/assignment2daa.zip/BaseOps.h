#include<stdio.h>
#include<stdlib.h>
#include"Base.h"
Base b;
int maxD;
int initializeBase(FILE *basefile);
int lookup(char c);
