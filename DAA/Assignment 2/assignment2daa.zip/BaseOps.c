#include<stdio.h>
#include<stdlib.h>
#include"Base.h"
Base b;
int maxD;
int initializeBase(FILE *basefile)
{
	

	int n=0,i=0;
	char c;
	while(!feof(basefile))
	{
			fscanf(basefile,"%c",&c);
			if(c!=' ')
				b.c[n++]=c;
	}
	return n;
}
int lookup(char c)
{
	
	int i;
	for(i=0;i<maxD;i++)
		if(b.c[i]==c)
			return i;
	return -1;
}


