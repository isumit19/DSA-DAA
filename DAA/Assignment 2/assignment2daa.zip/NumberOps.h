#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"Number.h"
#include"OtherOps.h"
FILE *f;
void PrintNumber(Number x)
{
	list *ptr = x.head;
	while(ptr)
	{
		fprintf(f,"%c",ptr->a);
		ptr=ptr->next;}
	fprintf(f,"(%d) ",x.base);
	//fprintf(f,"hi");

}
void display(Number a,char op,Number b,Number r)
{

	PrintNumber(a);
	fprintf(f," %c ",op);
	PrintNumber(b);
	fprintf(f," = ");
	PrintNumber(r);
	fprintf(f,"\n");	
}
Number createNumber(char *number_format)
{
	int i=0,BASE=0,digit;
	char c=number_format[i];
	while(c!=' ')
	{
		c=number_format[i];
		if(c>='0'&&c<='9')
			digit=c-'0',BASE=BASE*10+digit;
		i++;
	}
	//printf(" %d ",BASE);
	Number x;
	x.head=x.tail=NULL;
	x.base=BASE;
	//printf("%d\n",x.base);
	while(i<strlen(number_format) && number_format[i]!='\r')
	{
		if(lookup(number_format[i])!=-1)
			push(&x,number_format[i]);
		i++;
	}
	return x;
		
}
Number convert(Number n, int to_base)
{
	Number result;
	int pbase=n.base;
	if(to_base==10)
	{
		int num=0,power=1;
		list* ptr=n.tail;
		while(ptr)
		{
			
			int x=lookup(ptr->a);
			if(x==-1)
			{
				printf("Error");
				FILE *file= fopen("error.txt","w");
				fprintf(file,"INVALID CHARACTER");
				fclose(file);
				exit(0);
			}
			num+=lookup(ptr->a)*power;
			power*=pbase;
			ptr=ptr->prev;
		}
		char string[100];
		string_create(string,num,to_base);
		result= createNumber(string);
		result.decimal=num;
		return result;
	}
	else
	{
		char *s=fromDeci(s,to_base, n.decimal);
		char baseb[100];
		sprintf(baseb,"%d",to_base);
		strcat(baseb," ");
		strcat(baseb,s);
		return createNumber(baseb);		
	}
		
}

Number add(Number a, Number b)
{
	Number Num_in_dec1=convert(a,10);
	Number Num_in_dec2=convert(b,10);
	int result_in_dec=Num_in_dec1.decimal+Num_in_dec2.decimal;
	//printf("%d",result_in_dec);
	int base=max(a.base,b.base);
	check(base); // base checking
	char result[100];
	string_create(result,10,result_in_dec);
	Number x= createNumber(result);
	x.decimal=result_in_dec;
	return convert(x,base);
	
}
Number sub(Number a, Number b)
{
	Number Num_in_dec1=convert(a,10);
	Number Num_in_dec2=convert(b,10);
	int result_in_dec=Num_in_dec1.decimal-Num_in_dec2.decimal;
	int base=(a.base>b.base)?a.base:b.base;
	check(base); // base checking
	char result[100];
	string_create(result,10,result_in_dec);
	Number x= createNumber(result);
	x.decimal=result_in_dec;
	return convert(x,base);
	
}

