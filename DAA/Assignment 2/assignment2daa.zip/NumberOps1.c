#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"NumberOps1.h"
FILE *f;
list* newnode(char c)
{
	list *temp=(list*)malloc(sizeof(list));
	temp->a=c;
	temp->next=NULL;
	temp->prev=NULL;
	return temp;
}

void check(int base)
{
	if(base>maxD)
	{
		printf("Error");
		FILE *file= fopen("error.txt","w");
		fprintf(file,"INVALID BASE");
		fclose(file);
		exit(0);
	}
}
char reVal(int num) 
{ 
    return b.c[num];
}


char *strrev(char *str)
{
      char *p1, *p2;

      if (! str || ! *str)
            return str;
      for (p1 = str, p2 = str + strlen(str) - 1; p2 > p1; ++p1, --p2)
      {
            *p1 ^= *p2;
            *p2 ^= *p1;
            *p1 ^= *p2;
      }
      return str;
}

char* fromDeci(char res[], int base, int inputNum) 
{ 
    int index = 0;  

    while (inputNum > 0) 
    { 
        res[index++] = reVal(inputNum % base); 
        inputNum /= base; 
    } 
    res[index] = '\0'; 
  
    strrev(res);
  
    return res; 
}

void string_create(char string[],int base,int number)
{
	sprintf(string,"%d %d",base,number);	
}
int max(int a,int b)
{
	return (a>b)?a:b;
}
void push(Number* num,char c)
{

	list* ptr=newnode(c);

	if((*num).head==NULL)
		(*num).head=(*num).tail=ptr;
	else
	{	
		list* temp=(*num).head;
		while(temp->next)
			temp=temp->next;
		ptr->prev=temp;
		temp->next=ptr;
		(*num).tail=ptr;
	
	}

}

void PrintNumber(Number x)
{
	list *ptr = x.head;
	while(ptr)
	{
		fprintf(f,"%c",ptr->a);
		ptr=ptr->next;}
	fprintf(f,"(%d) ",x.base);

}
void display(Number a,char op,Number b,Number r)
{

	PrintNumber(a);
	fprintf(f," %c ",op);
	PrintNumber(b);
	fprintf(f," = ");
	PrintNumber(r);
	fprintf(f,"\n");	
}
Number createNumber(char *number_format)
{
	int i=0,BASE=0,digit;
	char c=number_format[i];
	while(c!=' ')
	{
		c=number_format[i];
		if(c>='0'&&c<='9')
			digit=c-'0',BASE=BASE*10+digit;
		i++;
	}
	Number x;
	x.head=x.tail=NULL;
	x.base=BASE;
	while(i<strlen(number_format) && number_format[i]!='\r')
	{
		if(lookup(number_format[i])!=-1||number_format[i]=='-')
			push(&x,number_format[i]);
		i++;
	}
	return x;
		
}

Number convert(Number n,int to_base)
{
	Number result;
	int pbase=n.base;
	if(to_base==10)
	{
		int num=0,power=1;
		list* ptr=n.tail;
		while(ptr)
		{
			
			int x=lookup(ptr->a);
			if(x==-1)
			{
				printf("Error");
				FILE *file= fopen("error.txt","w");
				fprintf(file,"INVALID CHARACTER");
				fclose(file);
				exit(0);
			}
			num+=lookup(ptr->a)*power;
			power*=pbase;
			ptr=ptr->prev;
		}
		char string[100];
		string_create(string,num,to_base);
		result= createNumber(string);
		result.decimal=num;
		return result;
	}
	else
	{
		char *s=fromDeci(s,to_base, n.decimal);
		char baseb[100];
		sprintf(baseb,"%d",to_base);
		strcat(baseb," ");
		strcat(baseb,s);
		return createNumber(baseb);		
	}

}
int toBase10(Number n)
{
	int pbase=n.base;
	int num=0,power=1;
		list* ptr=n.tail;
		while(ptr)
		{
			
			int x=lookup(ptr->a);
			if(x==-1)
			{
				printf("Error");
				FILE *file= fopen("error.txt","w");
				fprintf(file,"INVALID CHARACTER");
				fclose(file);
				exit(0);
			}
			num+=lookup(ptr->a)*power;
			power*=pbase;
			ptr=ptr->prev;
		}
	return num;
}
Number fromDec(int inputNum, int base)
{
	int index = 0,nflag=0;;
	if(inputNum<0)
		nflag=1,inputNum*=-1;;
	char *res=(char *) malloc(sizeof(char)*(100));;
	while (inputNum > 0) 
	{ 
		res[index++] = reVal(inputNum % base); 
		inputNum /= base; 
	}
	if(nflag) 
		res[index++]='-';
	res[index++]=' ';
	while(base>0)
		res[index++]=(char)(base%10+'0'),base/=10;
	res[index] = '\0'; 
	strrev(res);
   	return createNumber(res);
}

Number add(Number a, Number b)
{
	
	int result_in_dec=toBase10(a)+toBase10(b);
	//printf("%d\n",result_in_dec);
	int base=max(a.base,b.base);
	check(base); // base checking
	return fromDec(result_in_dec,base);
	
}
Number sub(Number a, Number b)
{
	
	int result_in_dec=toBase10(a)-toBase10(b);
	int base=max(a.base,b.base);
	check(base); // base checking
	return fromDec(result_in_dec,base);
	
}
