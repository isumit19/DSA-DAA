#include<stdio.h>
#include<stdlib.h>
typedef struct base{
	char c[100];
}Base;
