#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"NumberOps1.h"
int main()
{

		f=fopen("output.txt","w");
		FILE *F=fopen("File1.txt","r");
		maxD=initializeBase(F);
		fclose(F);
		F=fopen("File2.txt","r");
		char op[100],num1[100],num2[100];
		memset(op, 0, 100),memset(num1, 0, 100),memset(num2, 0, 100);
		int base1,base2;
		while(fgets(op, sizeof(op), F)!=0)
		{
			fgets(num1, sizeof(num1), F);
			fgets(num2, sizeof(num2), F);
			Number Num1=createNumber(num1);			
			Number Num2=createNumber(num2);
			
			if(op[0]=='a')
			{
					Number result=add(Num1,Num2);
					display(Num1,'+',Num2,result);
			}
			else if(op[0]=='s')
			{
					Number result=sub(Num1,Num2);
					display(Num1,'-',Num2,result);
			}
			
		
		}
		fclose(f);
		fclose(F);
}
