#include<stdio.h>
#include<stdlib.h>
typedef struct list1{
	char a;
	struct list1 *next,*prev;
}list;
typedef struct number{
	int base;
	list x;
	list *head,*tail;
	int decimal;
	
}Number;
